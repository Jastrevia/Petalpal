# Approved Fairy front_3q — aligned layer reconstruction review package

Status: **18 layers delivered for visual review; NOT visually approved or certified production-ready.** No animation has been created. Fine hair/cloth edge matting still needs review/refinement, especially over dark backgrounds. The flattened RGB sheet does not contain recoverable original wing alpha or hidden anatomy.

## Files and alignment

All 18 requested PNGs are RGBA, **1024×1024**, and are composited at **(0,0)** in the back-to-front order in `layers.json`. No layer is cropped, scaled or rotated. The original front_3q source pixels are translated once by **(-171,+210)** from the presentation sheet; source scale remains exactly 1. The source stance point `(683,686)` maps to the common root **(512,896)**. Visible bounds are `(416,376)–(602,896)`, safely inside the canvas.

Required layers: body_base, head_face, hair_back, hair_front, braided_updo, flower_accessory, wing_left, wing_right, arm_left_upper, arm_left_lower, arm_right_upper, arm_right_lower, dress_base, dress_front_petals, dress_side_petals, dress_back_petals, leg_left, leg_right.

Anatomical side naming is inferred from the approved front_3q pose: the near/screen-left arm is named character-right. The crossed-leg assignment and joint guides should be reviewed before motion authoring.

## Source preservation and reconstruction

Authority: `../../master/fairy_approved_structure.png`, SHA-256 `86eed8eb748ced65bf6215fab48224b9e05bb8be50c213eb287d54ec0bf270b8`.

The visible painting comes directly from that source. No pixels from the rejected image-generation candidate or deprecated Blender models are included. The user explicitly authorized Python pixel masking, transparency repair and compositing after the generated extraction failed its appearance/alignment checks.

- Hand-authored semantic masks separate the native-resolution painting.
- Original visible RGB is preserved exactly wherever the resulting alpha is 255. No hue, saturation, lighting, face, pose or costume redesign pass is applied.
- Alpha is reconstructed approximately from an estimated local paper background. Wing membranes retain continuous partial alpha. Pale skin is protected from accidental color-key removal.
- Edge decontamination is bounded to prevent paper-estimation errors becoming saturated color fringes. This modifies some partially transparent edge RGB; **zero color drift cannot be guaranteed for those pixels**.
- Hidden support extends adjacent original painted colors by at most **4 source pixels**, or **8 pixels** for selected body/head/hair/upper-arm joints. Support stays inside the named semantic region and beneath an already fully opaque higher layer. It cannot change the resting recomposition.
- These are conservative seam guards, not completed hidden body drawings. They can support small motion experiments after approval; they are insufficient for arbitrary turns, large arm swings or walk/run articulation. Do not extrapolate them into new anatomy.

## Review outputs

- `../../review/front_3q_recomposed.png` — transparent resting composite.
- `../../review/front_3q_layer_contact_sheet.png` — all 18 layers, using the same inspection window for every thumbnail. Only review thumbnails are resized; delivered layers remain native/aligned.
- `../../review/front_3q_source_comparison.png` — original source, reconstruction over estimated paper, and neutral-background composite.
- `../../review/front_3q_alpha_background_checks.png` — light/dark/Garden-like green comparisons. **Inspect pale residual fringes and cloth/strand boundaries here before approving the package.**

## Validation scope

Automated checks verify: exact requested file set; common dimensions; RGBA and transparent borders; root/placement metadata; exact recomposition from layer files; unchanged opaque source RGB; unchanged approved source and pre-existing application files; no animation frames or atlas outputs.

Those checks do not prove semantic layer cuts or recovered alpha are artist-approved. The source-derived cutout is itself a reconstruction; equality to it is not a claim of equivalence to an unavailable original PSD. Remaining fine-edge matting and hidden-anatomy limitations are material, not automatically passed by the numeric checks.

Rebuild with `python Resources/fairy/production/layers/build_front_3q_layers.py`. This deterministically overwrites this reconstruction's layer/review outputs, never the approved master. Preserve any future manual artist edits in a new revision before rebuilding.

No changes to GardenScene, FairyLayer, the app registry, approved reference, or Blender files. Stop at layer review; no idle/walk/run or sprite atlas is authorized by this package.
